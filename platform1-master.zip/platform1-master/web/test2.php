<?php
echo "checking test 2 is working or not";
?>